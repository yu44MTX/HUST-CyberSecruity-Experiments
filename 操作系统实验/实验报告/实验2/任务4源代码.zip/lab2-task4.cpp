#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <unistd.h>
#include <semaphore.h>

const int BUFFER_SIZE = 10;
int buffer[BUFFER_SIZE];
int itemCount = 0;
int inIndex = 0;
int outIndex = 0;

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
sem_t emptySlots;
sem_t fullSlots;

void* producer(void* arg)
{
    int id = *(static_cast<int*>(arg));
    int start = id == 1 ? 1000 : 2000;
    int end = id == 1 ? 1999 : 2999;

    for (int i = start; i <= end; i++)
    {
        usleep((rand() % 901 + 100) * 1000); // ������100ms-1s

        sem_wait(&emptySlots);
        pthread_mutex_lock(&mtx);

        buffer[inIndex] = i;
        std::cout << "Producer " << id << " produced: " << buffer[inIndex] <<" at "<<inIndex<< std::endl;
        inIndex = (inIndex + 1) % BUFFER_SIZE;
        itemCount++;

        pthread_mutex_unlock(&mtx);
        sem_post(&fullSlots);
    }

    return nullptr;
}

void* consumer(void* arg)
{
    int id = *(static_cast<int*>(arg));

    while (true)
    {
        usleep((rand() % 901 + 100) * 1000); // ������100ms-1s

        sem_wait(&fullSlots);
        pthread_mutex_lock(&mtx);

        int data = buffer[outIndex];
        std::cout << "Consumer " << id << " consumed: " << data <<" at "<<outIndex<< std::endl;
        outIndex = (outIndex + 1) % BUFFER_SIZE;
        itemCount--;

        pthread_mutex_unlock(&mtx);
        sem_post(&emptySlots);
    }

    return nullptr;
}

int main()
{
    srand(static_cast<unsigned int>(time(nullptr)));

    sem_init(&emptySlots, 0, BUFFER_SIZE);
    sem_init(&fullSlots, 0, 0);

    int producerId1 = 1;
    int producerId2 = 2;
    int consumerId1 = 1;
    int consumerId2 = 2;
    int consumerId3 = 3;

    pthread_t producerThread1, producerThread2, consumerThread1, consumerThread2, consumerThread3;

    pthread_create(&producerThread1, nullptr, producer, &producerId1);
    pthread_create(&producerThread2, nullptr, producer, &producerId2);
    pthread_create(&consumerThread1, nullptr, consumer, &consumerId1);
    pthread_create(&consumerThread2, nullptr, consumer, &consumerId2);
    pthread_create(&consumerThread3, nullptr, consumer, &consumerId3);

    pthread_join(producerThread1, nullptr);
    pthread_join(producerThread2, nullptr);
    pthread_join(consumerThread1, nullptr);
    pthread_join(consumerThread2, nullptr);
    pthread_join(consumerThread3, nullptr);

    sem_destroy(&emptySlots);
    sem_destroy(&fullSlots);

    return 0;
}

