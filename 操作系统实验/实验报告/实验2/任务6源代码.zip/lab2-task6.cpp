#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_PHILOSOPHERS 5

pthread_mutex_t mutex[NUM_PHILOSOPHERS];
pthread_mutex_t chop;
int chops = 0;
int ate[NUM_PHILOSOPHERS] = {0};
int flag = 1;

void *philosopher(void *t) {
    float think;
    int i = *((int*) t);
    printf("%d\n", i);
    while (flag) {
        think = (rand() % 400 + 100) / 1000;
        sleep(think);   //˼��a
        if (chops == 4) continue;
        pthread_mutex_lock(&mutex[i]); //����
        pthread_mutex_lock(&chop);
        chops++;
        pthread_mutex_unlock(&chop);
        sleep(2);
        pthread_mutex_lock(&mutex[(i+1) % NUM_PHILOSOPHERS]);
        //�ȴ����ҿ��ӿ���
        //�Է�
        ate[i] = 1;
        printf("Philosopher %d is eating\n", i+1);
        think = (rand() % 400 + 100) / 1000;
        sleep(think);
        //���¿���
        pthread_mutex_unlock(&mutex[i]);
        pthread_mutex_unlock(&mutex[(i+1) % NUM_PHILOSOPHERS]);

        pthread_mutex_lock(&chop);
        chops--;
        pthread_mutex_unlock(&chop);
    }
    pthread_exit(0);
}

int main() {
    pthread_t philosophers[NUM_PHILOSOPHERS];
    int i;
    int philosophersIndex[NUM_PHILOSOPHERS];

    pthread_mutex_init(&chop, NULL);
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_mutex_init(&mutex[i], NULL);
    }

    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        philosophersIndex[i] = i;
        pthread_create(&philosophers[i], NULL, philosopher, (void*)&philosophersIndex[i]);
    }

    sleep(10);  // ����ѧ�ҾͲ�һ��ʱ��

    flag = 0;   // ���ñ�־λ����ѭ��
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_join(philosophers[i], NULL);
    }

    pthread_mutex_destroy(&chop);
    for (i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_mutex_destroy(&mutex[i]);
    }

    return 0;
}
