#include <iostream>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t mutex;
int countA = 1;
int countB = 100;

void* threadFunctionA(void*) {
    while (countA <= 100) {
        pthread_mutex_lock(&mutex);
        std::cout << "Thread A: " << countA << std::endl;
        countA++;
        pthread_mutex_unlock(&mutex);
        usleep(200000); // �ӳ� 200 ����
    }
    pthread_exit(NULL);
}

void* threadFunctionB(void*) {
    while (countB >= 1) {
        pthread_mutex_lock(&mutex);
        std::cout << "Thread B: " << countB << std::endl;
        countB--;
        pthread_mutex_unlock(&mutex);
        usleep(200000); // �ӳ� 200 ����
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t threadA, threadB;
    pthread_mutex_init(&mutex, NULL);

    pthread_create(&threadA, NULL, threadFunctionA, NULL);
    pthread_create(&threadB, NULL, threadFunctionB, NULL);

    pthread_join(threadA, NULL);
    pthread_join(threadB, NULL);

    pthread_mutex_destroy(&mutex);

    return 0;
}
