#!/bin/bash

# 指定目录路径
directory=""D:\\桌面""

# 获取当前日期和时分
suffix=$(date +"%Y-%m-%d-%H-%M")

# 遍历目录中的所有txt文件
for file in "$directory"/*.txt; do
    # 提取文件名和扩展名
    filename=$(basename "$file")
    extension="${filename##*.}"
    filename="${filename%.*}"

    # 添加日期和时分后缀
    new_filename="${filename}-${suffix}.${extension}"

    # 检查新文件名是否已存在，如果存在则更新后缀
    counter=1
    while [[ -e "$directory/$new_filename" ]]; do
        new_filename="${filename}-${suffix}-${counter}.${extension}"
        counter=$((counter+1))
    done

    # 重命名文件
    mv "$file" "$directory/$new_filename"
done