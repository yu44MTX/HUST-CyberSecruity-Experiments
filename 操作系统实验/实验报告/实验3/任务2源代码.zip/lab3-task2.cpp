#include <iostream>
#include<ctime>
#include<cstdlib>
using namespace std;

int page_num;       //ҳ����� 
int page_size;      //ÿһ���ܱ����ָ����
int command_num;    //ָ������
int fifo_index=0;   //�Ƚ��ȳ�ջ��
int missing_cnt=0;  //ȱҳ����
int hit_cnt=0;      //���д���

//�����
struct v_page{
    bool visit;     //�Ƿ�ʹ��
    int command;    //��ָ���ַ
    int in_time;    //����ҳ��ʱ��
    int last_time;  //�ϴ�ʹ��ʱ��
    void init()
    {
        visit = false;
        command = -1;
        in_time = 0;
        last_time = 4000;
    }
} page[16];

//������
struct p_block
{
    int index;
    int command;
} commands[2048];

void swap(p_block &a, p_block &b)
{
    int x=a.index, y=a.command;
    a.index = b.index, a.command = b.command;
    b.index = x, b.command = y;
}

//��ʼ���ڴ�ռ�
void init_pages(v_page *v, int n)
{
    for(int i=0; i<n; i++)
        page[i].init();
}

//����ָ�
void init_commands(p_block *p, int n)
{
    srand((unsigned)time(NULL));
    for(int i=0; i<n; i++)
    {
        p[i].index = i;
        p[i].command = rand()%command_num;
    }
}

//����ڴ���Ϣ
void print_pages()
{
	cout<<"page frame:";
    for(int i=0; i<page_num; i++)
    {
        if(page[i].visit)
            cout <<page[i].command <<'\t';
        else
            cout <<"NULL\t";
    }
    cout <<endl<<endl;
}

//�Ƿ�����
int is_exist(v_page *v, int command)
{
    for(int i=0; i<page_num; i++)
    {
        if(v[i].visit && command/page_size == v[i].command)
            return i;
    }
    return -1;
}

//FIFO
void FIFO()
{
    for(int i=0; i<command_num; i++)
    {
        cout <<"Command[" <<commands[i].command <<"]\tIndex[" <<commands[i].index <<"]\n";
        //�ж�ָ���Ƿ��Ѿ����ؽ��ڴ�
        int flag=is_exist(page, commands[i].command);
        //�����ڴ���
        if(flag != -1)
        {
            cout <<"Hit!\t\t\n";
            hit_cnt++;
        }
        //�����ڴ�����ؽ��ڴ�
        else
        {
            cout <<"Missing!\t\n";
            missing_cnt++;            
            int index=commands[i].index/page_size;
            page[fifo_index].visit = true;
            page[fifo_index].command = index;
            fifo_index = (fifo_index+1)%page_num;
        }
        //����ڴ���Ϣ
        print_pages();
        
    }
}

void LRU()
{
    for(int i=0; i<command_num; i++)
    {
        cout <<"Command: [" <<commands[i].command <<"]\tIndex: [" <<commands[i].index <<"]\n";
        //�ж�ָ���Ƿ��Ѿ����ؽ��ڴ�
        int flag=is_exist(page, commands[i].command);
        //�����ڴ���
        if(flag != -1)
        {
            cout <<"Hit!\t\t\n";
            hit_cnt++;
            page[flag].last_time=0;
        }
        //�����ڴ�����ؽ��ڴ�
        else
        {
            cout <<"Missing!\t\n";
            missing_cnt++;
            //�����滻λ��
            int max_time=-1;
            int index=0;
            for(int j=0; j<page_num; j++)
            {
                if(!page[j].visit)
                {
                    index=j;
                    break;
                }
                else
                {
                    if(page[j].last_time>max_time)
                    {
                        max_time = page[j].last_time;
                        index = j;
                    }
                } 
            }

            page[index].visit = true;
            page[index].command = commands[i].index/page_size;
            page[index].last_time = 0;
            page[index].in_time = 0;
        }
        for(int j=0; j<page_num; j++)
            if(page[j].visit)
                page[j].last_time++;
        //����ڴ���Ϣ
        print_pages();
    }
}

void OPT()
{
    for(int i=0; i<command_num; i++)
    {
        cout <<"Command: [" <<commands[i].command <<"]\tIndex: [" <<commands[i].index <<"]\n";
        //�ж�ָ���Ƿ��Ѿ����ؽ��ڴ�
        int flag=is_exist(page, commands[i].command);
        //�����ڴ���
        if(flag != -1)
        {
            cout <<"Hit!\t\t\n";
            hit_cnt++;
        }
        //�����ڴ���
        else
        {
            cout <<"Missing!\t\n";
            missing_cnt++;

            //ȷ���滻λ��
            int index = 0;
            int max_next = -1;
            for(int j=0; j<page_num; j++)
            {
                //������п�λ
                if(!page[j].visit)
                {
                    index = j;
                    break;
                }
                //û�п�λ���Ҵ���λ
                else
                {
                    int k;
                    int temp=commands[i].index/page_size;
                    for(k=i+1; k<command_num; k++)
                    {
                        if(commands[k].index/page_size == temp && k-i>max_next)
                        {
                            index = j;
                            max_next = k-i;
                            break;
                        }
                    }
                    if(k==command_num)
                    {
                        index = j;
                        max_next = command_num;
                    }
                }
            }
            page[index].visit = true;
            page[index].command = commands[i].index/page_size;
            page[index].last_time = 0;
            page[index].in_time = 0;
        }
        //����ڴ���Ϣ
        print_pages();
    }
}

int main()
{
    string choice;
	cout <<"How many page frame[3~8]: ";
    cin >>page_num;
    cout <<"How big each page[1~16]: ";
    cin >>page_size;
    cout <<"How many commands: ";
    cin >> command_num;
    init_commands(commands, command_num);
    init_pages(page, page_num);
    while(1)
    {
        cout <<"Which replacement algorithm[FIFO/LRU/OPT]: ";
        cin >>choice;
        if(choice=="FIFO")
        {
            FIFO();
            break;
        }
        else if(choice=="LRU")
        {
            LRU();
            break;
        }
        else if(choice=="OPT")
        {
            OPT();
            break;
        }
        else
            cout <<"Illegal input!" <<endl;
    }   
    cout <<endl;
    cout <<"Hit times: " <<hit_cnt <<endl;
    cout <<"Minssing times: " <<missing_cnt <<endl;
    cout <<"Minssing rate: " <<(double)(command_num-hit_cnt)/command_num*100 <<"%\n";
    return 0;
}
